changes 20250926

Updated ServerStart and ServerConfig Name
setup server details
setup VPP & CF